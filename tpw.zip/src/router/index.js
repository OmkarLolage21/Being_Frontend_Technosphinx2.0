import { createRouter, createWebHistory } from 'vue-router';
import PrescriptionBill from '../components/PresecriptionBill.vue'; // Import PrescriptionBill component
import ZenModeInterface from '../components/ZenModeInterface.vue';
import BookAppointment from '@/components/BookAppointment.vue';
// import App from '../App.vue';

const routes = [
  {
    path: '/prescription-bill', // Route for the PrescriptionBill component
    component: PrescriptionBill,
  },
  {
    path: '/book-appointment', // Route for the PrescriptionBill component
    component: BookAppointment,
  },
  {
    path: '/zen-mode', // Route for the PrescriptionBill component
    component: ZenModeInterface,
  },
  {
    path: '/doc-connect', // Route for the PrescriptionBill component
    component: PrescriptionBill,
  },
];

const router = createRouter({
  history: createWebHistory(),
  routes,
});

export default router;
