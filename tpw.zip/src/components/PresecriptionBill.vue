<template>
    <div class="prescription-uploader">
      <input
        type="file"
        @change="handleFileUpload"
        accept="image/*"
        ref="fileInput"
        style="display: none"
      />
      <button @click="$refs.fileInput.click()" class="upload-btn">
        Upload Prescription
      </button>
      <div v-if="isLoading" class="loading">Processing prescription...</div>
      <div v-if="error" class="error">{{ error }}</div>
      <div v-if="cart.length > 0" class="cart">
        <h3>Cart</h3>
        <ul>
          <li v-for="(item, index) in cart" :key="index">
            {{ item.name }} - Quantity: {{ item.quantity }}
          </li>
        </ul>
        <button @click="proceedToBilling" class="billing-btn">Proceed to Billing</button>
      </div>
    </div>
  </template>
  
  <script>
  export default {
    name: 'PrescriptionBill',
    data() {
      return {
        isLoading: false,
        error: null,
        cart: [],
      };
    },
    methods: {
      handleFileUpload(event) {
        const file = event.target.files[0];
        if (!file) return;
  
        this.isLoading = true;
        this.error = null;
  
        // Simulate image processing and text extraction
        setTimeout(() => {
          this.processPrescription(file);
        }, 2000);
      },
      processPrescription() {
        // In a real application, you would send the file to a server for processing
        // Here, we'll simulate the extraction of medicine information
        const mockExtractedData = [
          { name: 'Aspirin', quantity: 30 },
          { name: 'Lisinopril', quantity: 60 },
          { name: 'Metformin', quantity: 90 },
        ];
  
        this.addToCart(mockExtractedData);
        this.isLoading = false;
      },
      addToCart(medicines) {
        this.cart = medicines;
      },
      proceedToBilling() {
        // In a real application, you would initiate the billing process here
        console.log('Proceeding to billing with cart:', this.cart);
        // You could emit an event here to be handled by a parent component
        this.$emit('proceed-to-billing', this.cart);
      },
    },
  };
  </script>
  
  <style scoped>
  .prescription-uploader {
    margin-top: 20px;
    padding: 20px;
    border: 1px solid #ddd;
    border-radius: 8px;
  }
  
  .upload-btn, .billing-btn {
    background-color: #004f9e;
    color: white;
    border: none;
    padding: 10px 15px;
    border-radius: 5px;
    cursor: pointer;
    font-size: 14px;
    margin-bottom: 10px;
  }
  
  .upload-btn:hover, .billing-btn:hover {
    background-color: #003d7b;
  }
  
  .loading, .error {
    margin-top: 10px;
    font-style: italic;
  }
  
  .error {
    color: red;
  }
  
  .cart {
    margin-top: 20px;
  }
  
  .cart ul {
    list-style-type: none;
    padding: 0;
  }
  
  .cart li {
    margin-bottom: 5px;
  }
  </style>